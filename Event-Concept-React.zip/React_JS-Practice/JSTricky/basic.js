//         console.log((0.1 + 0.2) == 0.3);
//         console.log(0.1 * 3 == 0.3);
//         console.log(0.9 / 3 == 0.3);
        
// for (var i = 0; i < 10; i++) { 
//     setTimeout(() => {
//          console.log(i); 
//         }, 1000
//     )}

//    function outer() {
//      var b = 2; 
//      console.log(b);
     
//      function inner() {
//              console.log("hhh",b);
//          b++;
//          console.log("mmm", b); 
//          var b = 3; 
//               console.log("nnn",b);

//         } inner(); 
//              console.log(b);

//     }
//  outer();



//  console.log(undefined++); // NaN

// console.log(true + 1);
// console.log(false + 1);
// console.log(true * 0);
// console.log(false* 1);
// console.log(false/1);
// console.log(false/ 0);


// (function () {
//   try {
//     throw new Error();
//   } catch (x) {
//     var x = 1, y = 2;
//     console.log(x); 
//   }
//   console.log(x); 
//   console.log(y); 
// })();


// Promise.resolve(3)
//   .then((res) => {
//     console.log(res); 
//   })
//   .catch()
//   .then()
//   .then(res => res)
//   .then()
//   .catch()
//   .then((res) => {
//     console.log(res); 
//   });


// console.log([2] == [2]);

// test(); 

// function test() {
//     console.log("Hello");
    
//   return true;  
// }

