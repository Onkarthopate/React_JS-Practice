// function greet(){
//     console.log("Function Declaration is is Hoisted!");
    
// }
// greet();   

// greet();
// function greet(){
//     console.log("Function Declaration is Hoisted!");
    
// }

// =====================================================


// const greet = function(){
//     console.log("Function Expression is Not Hoisted!");
    
// }
// greet();



greet();

const greet = function(){
    console.log("Function Expression is Not Hoisted!");
    
}
