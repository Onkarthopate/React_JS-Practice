// function fun() {
//     console.log("Hello, World!");
// }
// function fun2(action) {
//     action();
//     action();
// }

// fun2(fun);


// const n = [1, 2, 3, 4, 5];
// const square = n.map((num) => num * num);
// console.log(square);
// console.log(n);

// const n = [1, 2, 3, 4, 5];
// const even = n.filter((num) => num % 2 === 0);
// console.log(even);


// const n = [1, 2, 3, 4, 5];
// const sum = n.reduce((acc, curr) => acc + curr, 0);
// console.log(sum);