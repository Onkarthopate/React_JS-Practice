function hello(){
    console.log("Hello");
    
}
hello();