let a=990;
let b=870
let c=880;

if(a>=b && a>=c){

   
    console.log(a, "a is Bigger");    
}
else  if(b>=c){
        console.log(b ,"b is bigger");
        
    }
else{
    console.log(c , "c is bigger"); 
}