let a=20;
let b=30;
if(a<=b){
    console.log("a is smaller",a);
}