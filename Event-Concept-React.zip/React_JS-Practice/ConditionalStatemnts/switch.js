let color = "pink";

switch (color) {
    case "Green":
        console.log("color is match Green", color);
        break;
    case "Blue":
        console.log("color is match Blue", color);
        break; 
    case "pink":
        console.log("color is match pink", color);
        break; 
    case "red":
        console.log("color is match red", color);
        break;
    default :
    console.log("Sorry Color is not match");
        

}
