var a = 55;
console.log(a);


console.log(c); // undefined
var c = 23;
console.log(c);

console.log(x); // can't access x before initializaton
let x = 34;
console.log(x);

console.log(m);  // can't access x before initializaton
const m = 77;
console.log(m);


