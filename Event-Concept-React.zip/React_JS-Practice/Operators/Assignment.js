// assignment operator
let a = 7;
console.log("Assignment: a = 7, a =", a);

// addition assing
a += 5;  // a = a + 5
console.log("Addition Assignment: a += 5, a =", a);

// subtraction assing
a -= 5;  // a = a - 5
console.log("Subtraction Assignment: a -= 5, a =", a);

// multiplication assing
a *= 2;  // a = a * 2
console.log("Multiplication Assignment: a *= 2, a =", a);

// division assing
a /= 2;  // a = a / 2
console.log("Division Assignment: a /= 2, a =", a);

// remainder assing
a %= 2;  // a = a % 2
console.log("Remainder Assignment: a %= 2, a =", a);

// exponentiation assing
a **= 2;  // a = a**2
console.log("Exponentiation Assignment: a **= 7, a =", a);