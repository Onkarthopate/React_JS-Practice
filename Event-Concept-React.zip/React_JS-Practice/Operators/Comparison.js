// equal to operator
console.log("Equal to: 2 == 2 is", 2 == 2);

// not equal 
console.log("Not equal to: 3 != 3 is", 3 != 3);

// strictly equal to 
console.log("Strictly equal to: 2 === '2' is", 2 === '2');

// strictly not equal to 
console.log("Strictly not equal to: 2 !== '2' is", 2 !== '2');

// greater than 
console.log("Greater than: 3 > 3 is", 3 > 3);

// less than operator
console.log("Less than: 2 > 2 is", 2 > 2);

// greater than or equal to 
console.log("Greater than or equal to: 3 >= 3 is", 3 >= 3);

// less than or equal to 
console.log("Less than or equal to: 2 <= 2 is", 2 <= 2);