let x = 5;

// addition 
console.log("Addition: x + 3 = ", x + 3);

// subtraction 
console.log("Subtraction: x - 3 =", x - 3);

// multiplication 
console.log("Multiplication: x * 3 =", x * 3);

// division 
console.log("Division: x / 3 =", x / 3);

// remainder 
console.log("Remainder: x % 3 =", x % 3);

// increment 
console.log("Increment: ++x =", ++x);

// decrement 
console.log("Decrement: --x =", --x);

// exponentiation 
console.log("Exponentiation: x ** 3 =", x ** 3);