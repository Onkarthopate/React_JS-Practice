
// we can't use try without catch and finally 

// try{
//     console.log("Start Program");
//     throw new Error("Error Occured");
// }


// try catch

// try {
//   let result = [2, 3, 4, 5, 6, 7, 8];
// let i = 8;
//   if(i<0 || i >= result.length){
//     throw new Error("Array index out of bound");
//   }     
// //   console.log(resut[8]);
//   console.log(result[i]);
// } catch (e) {
//   console.log("Caught an error:", e.message);
// }


// try catch finally


// function sum(a,b){

// try{
//     if(b == 0){
//         throw new Error("Cannot divide by zero");
//     }
//     let ans = a/b;
//     console.log(ans);  
// }catch(e){
//     console.log("error ", e.message);
    
// }finally{
//     console.log("operation succesed");
    
// }
// }

// sum(6,0);


// try finally

try{
    console.log("file opened succesfully!");
    
}finally{
    console.log("file has been closed");
    
}