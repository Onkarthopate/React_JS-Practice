// "use strict"

// x = 10;
// console.log(x);
// ===========================================

a = 10;
console.log(a);


var a=129;
console.log(a);
var a=45;
console.log(a);
a=42;
console.log(a);

// =================================================


let m =34;
console.log(m);
m=45;
console.log(m);

// let m = 23;
// console.log(m);


// =========================================

// const z =56;
// console.log(z);

// z=67;
// console.log(z);

// const z=78;
// console.log(z);







