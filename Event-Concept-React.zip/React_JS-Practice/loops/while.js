// let n = 8;
// let i=0;
// while(i < n ){
//     if(i%2 == 0){
//         console.log(i);
        
//     }
//     i++;
// }