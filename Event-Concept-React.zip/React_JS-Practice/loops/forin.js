const person = {
    "name":"omkara",
    "age":23,
    "college": "MGV Nira"
}

for (const a in person) {
   console.log(a ,":", person[a]);
   
}