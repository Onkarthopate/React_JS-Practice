// let color = ['red', 'pink', 'blue','yellow'];

// for (const e of color) {
//     console.log(e);
    
// }


let a1 = [1, 2, 3, 4, 5];
console.log(a1);
console.log(a1[2]);

let a2 = [1, "two", { name: "Objecvt" }, [3, 4, 5]];
console.log(a2);
console.log(a2[2]);
console.log(a2[2].name);