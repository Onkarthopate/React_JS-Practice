// Numbers:
let length = 16;
let weight = 7.5;

// Strings:
let color = "Yellow";
let lastName = "Johnson";

// Booleans
let x = true;
let y = false;

// Object:
const person = {firstName:"John", lastName:"Doe"};

// Array object:
const cars = ["Saab", "Volvo", "BMW"];

// Date object:
const date = new Date("2022-03-25");


// console.log(x+y);
// console.log(person+23+"omkara");
// console.log(34+43-'3');
// console.log(NaN=undefined);
// console.log({}+[]);
// console.log(undefined-7);
// console.log(9+NaN);
// console.log(Object+Object);
// console.log(23+"omkar"-23+NaN);
// console.log(0-undefined);
// console.log(1+true);
