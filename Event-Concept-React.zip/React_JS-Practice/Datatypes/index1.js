console.log(typeof(String));
console.log(typeof(Number));
console.log(typeof(Boolean));
console.log(typeof(null));
console.log(typeof(undefined));
console.log(typeof(NaN));
console.log(typeof(Array));
console.log(typeof(Object));
console.log(typeof(Date));
console.log(typeof(function name(params) {
    
}));


console.log(typeof("omkara"));
console.log(typeof(34));
console.log(typeof(false));
console.log(typeof(null));
console.log(typeof(undefined));
console.log(typeof(NaN));
console.log(typeof([4,44,4]));
console.log(typeof({name:"omkar"}));
console.log(typeof(4/9/2003));