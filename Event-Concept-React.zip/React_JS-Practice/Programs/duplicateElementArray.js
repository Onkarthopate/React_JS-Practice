function findDupliacte(arr[]){

    for (const ele of arr) {

        let set = Set()
        
    }
}

let array = [3,4,5,6,7,8,2,4,5,8];
console.log(findDupliacte(array));
