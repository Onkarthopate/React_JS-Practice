import React, { useState } from "react";

function NoDebounce() {
  const [query, setQuery] = useState("");

  const handleChange = (e) => {
    const value = e.target.value;
    setQuery(value);
    console.log("Searching for:", value);
  };

  return (
    <div>
      <h2>Without Debouncing</h2>
      <input
        type="text"
        value={query}
        onChange={handleChange}
        placeholder="Type to search..."
      />
    </div>
  );
}

export default NoDebounce;
