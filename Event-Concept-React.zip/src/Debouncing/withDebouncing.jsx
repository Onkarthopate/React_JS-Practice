import React, { useState, useEffect } from "react";

function WithDebounce() {
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(query);
    }, 800); // debounce delay

    return () => clearTimeout(timer); // clear timer if query changes without clear it same as without-debouncing(repeting letters each time )
  }, [query]);

  useEffect(() => {
    if (debouncedQuery) {
      console.log("Searching for:", debouncedQuery);
    }
  }, [debouncedQuery]);

  return (
    <div>
      <h2>With Debouncing</h2>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Type to search..."
      />
    </div>
  );
}

export default WithDebounce;
