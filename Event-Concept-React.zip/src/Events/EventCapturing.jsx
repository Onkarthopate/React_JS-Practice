import React from "react";

function EventCapturing() {
    function handleParentCapture() {
        console.log(" Capturing: Parent div (onClickCapture)");
    }

    function handleParent1() {
        console.log(" Bubbling: Parent 1 Div (onClick)");
    }

    function CookFood() {
        console.log("🍳 I Love To Cook Food");
    }

    function Swimming() {
        console.log("🏊 I Love To Swim");
    }

    function Sleep() {
        console.log("😴 I love to sleep");
    }

    return (
        <>
            <div className="Parent-div" onClickCapture={handleParentCapture}>
                <div className="Parent_InnerDIv" onClickCapture={handleParent1}>
                    <button onClick={CookFood}>Button1</button>
                </div>
                <button onClick={Swimming}>Button2</button>
                <button onClick={Sleep}>Button3</button>
            </div>
        </>
    );
}

export default EventCapturing;
