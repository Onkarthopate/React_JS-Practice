import React from "react";

// function EventDelegation() {
//     function handleClick(event) {
//         const { id } = event.target;

//         switch (id) {
//             case "cookBtn":
//                 console.log("I Love To Cook Food");
//                 break;
//             case "swimBtn":
//                 console.log("I Love To Swim");
//                 break;
//             case "sleepBtn":
//                 console.log("I love to sleep");
//                 break;
//             default:
//                 console.log("Clicked something else");
//         }
//     }

//     return (
//         <div className="Parent-div" onClick={handleClick}>
//             <button id="cookBtn">Button1</button>
//             <button id="swimBtn">Button2</button>
//             <button id="sleepBtn">Button3</button>
//         </div>
//     );
// }


// function EventDelegation() {
//     function handleClick(event) {

//         if (event.target === event.currentTarget) {
//             console.log("I am Parent Div");
//             return;
//         }
//         else {
//             const { className } = event.target;

//             switch (className) {
//                 case "cookBtn":
//                     console.log("I Love To Cook Food");
//                     break;
//                 case "swimBtn":
//                     console.log("I Love To Swim");
//                     break;
//                 case "sleepBtn":
//                     console.log("I love to sleep");
//                     break;

//                 default:
//                     console.log("Clicked something else");
//             }
//         }


//     }

//     return (
//         <div className="Parent-div" onClick={handleClick}>
//             <button className="cookBtn">Button1</button>
//             <button className="swimBtn">Button2</button>
//             <button className="sleepBtn">Button3</button>
//         </div>
//     );
// }


// function EventDelegation() {
//     function handleClick(event) {

//             const action  = event.target.dataset.action;

//             if (!action) {
//       console.log("🟢 Clicked on Parent Div (not a button)");
//       return;
//     }
//             switch (action) {
//                 case "cookBtn":
//                     console.log("I Love To Cook Food");
//                     break;
//                 case "swimBtn":
//                     console.log("I Love To Swim");
//                     break;
//                 case "sleepBtn":
//                     console.log("I love to sleep");
//                     break;

//                 default:
//                     console.log("Clicked something else");
//             }
//         }

//     return (
//         <div className="Parent-div" onClick={handleClick}>
//             <button data-action="cookBtn">Button1</button>
//             <button data-action="swimBtn">Button2</button>
//             <button data-action="sleepBtn">Button3</button>
//         </div>
//     );

// }

function EventDelegation() {
    // Define actions in a map
    const actionMap = {
        cook: () => console.log("I Love To Cook Food"),
        swim: () => console.log("I Love To Swim"),
        sleep: () => console.log("I love to sleep"),
    };

    function handleClick(event) {
        const action = event.target.dataset.action;

        if (event.target.dataset.action == event.currentTarget.dataset.action) {
            console.log("Clicked on Parent Div");
            return;

        }
        else {
            if (action && actionMap[action]) {
                actionMap[action]();
            }
        }

    }

    return (
        <div className="Parent-div" onClick={handleClick}>
            <button data-action="cook">Button1</button>
            <button data-action="swim">Button2</button>
            <button data-action="sleep">Button3</button>
        </div>
    );
}


export default EventDelegation;
