import React from "react";

function NormalExampleEvent() {
  const handleCardClick = () => {
    console.log("🟢 Card clicked");
  };

  const handleLinkClick = (event) => {
    event.stopPropagation(); //Stop Bubbling Event
    event.preventDefault(); 
    // when this not using display for 1s and 
    // then disapper but when its using dispay on brower (Stop submiting information by default and see ours)

    console.log(" Link clicked,");
  };

  return (
    <div
      onClick={handleCardClick}
      style={{ padding: "20px", background: "lightblue" }}>
      Clickable Card
      <br />
      <a href="https://example.com" onClick={handleLinkClick}>
        Go to Example.com
      </a>
    </div>
  );
}

export default NormalExampleEvent;
