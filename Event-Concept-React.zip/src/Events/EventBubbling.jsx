import React from "react";

function EventBubbling() {

    function handleParent() {
        console.log("This is Trigged By Parent Div");

    }
    function handleParent1() {
        console.log("This is Trigged By Parent 1  Div");

    }

    function CookFood(e) {
        // e.stopPropagation();  // avoid to event bubbling
        console.log("I Love To Cook Food ");

    }

    function Swimming() {
        console.log("I Love To Swim");

    }

    function Sleep() {
        console.log("I love to sleep");

    }


    return (
        <>
            <div className="Parent-div" onClick={handleParent}>
                <div className="Parent_InnerDIv" onClick={handleParent1}>
                    <button className="Child-div" onClick={CookFood}>Button1</button>
                </div>
                <button className="Child-div" onClick={Swimming}>Button2</button>
                <button className="Child-div" onClick={Sleep}>Button3</button>
            </div>
        </>
    )
}

export default EventBubbling;