// import './App.css'

import WithDebounce from "./Debouncing/withDebouncing"

// import EventCapturing from "./Events/EventCapturing"
// import NoDebounce from "./Debouncing/withoutDebouncing"
// import NormalExampleEvent from "./Events/PreventDefault-StopPropagate"
// import EventDelegation from "./Events/EventDeligation"

// import EventBubbling from "./EventBubbling/EventBubbling"

function App() {

  return (
    <>
    {/* <EventBubbling/> */}
    {/* <EventDelegation /> */}
    {/* <EventCapturing /> */}

    {/* <NormalExampleEvent/> */}

    {/* <NoDebounce/> */}

    <WithDebounce/>

    </>
  )
}

export default App
